//Configuração de rotas e App principal
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

// Componentes
import Header from './components/Header';
import Home from './components/Home';
import FornecedorList from './components/FornecedorList';
import FornecedorForm from './components/FornecedorForm';
import FornecedorDetail from './components/FornecedorDetail';

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/fornecedores" element={<FornecedorList />} />
        <Route path="/fornecedores/novo" element={<FornecedorForm />} />
        <Route path="/fornecedores/:id" element={<FornecedorDetail />} />
        <Route path="/fornecedores/editar/:id" element={<FornecedorForm />} />
      </Routes>
    </Router>
  );
}

export default App;
