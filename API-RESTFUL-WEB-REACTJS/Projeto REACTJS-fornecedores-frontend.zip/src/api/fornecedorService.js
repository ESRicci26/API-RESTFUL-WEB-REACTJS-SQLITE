// Este serviço encapsula todas as chamadas à API
import axios from 'axios';

const API_URL = 'http://localhost:8080/api/fornecedores';

export const getFornecedores = async () => {
  return axios.get(API_URL);
};

export const getFornecedorById = async (id) => {
  return axios.get(`${API_URL}/${id}`);
};

export const createFornecedor = async (fornecedor) => {
  return axios.post(API_URL, fornecedor);
};

export const updateFornecedor = async (id, fornecedor) => {
  return axios.put(`${API_URL}/${id}`, fornecedor);
};

export const deleteFornecedor = async (id) => {
  return axios.delete(`${API_URL}/${id}`);
};
