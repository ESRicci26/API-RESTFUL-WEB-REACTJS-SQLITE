// Exibe detalhes de um fornecedor específico
import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { getFornecedorById, deleteFornecedor } from '../api/fornecedorService';
import { Card, Button, Container, Row, Col, Alert } from 'react-bootstrap';

const FornecedorDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [fornecedor, setFornecedor] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    getFornecedorById(id)
      .then(response => {
        setFornecedor(response.data);
      })
      .catch(err => {
        console.error('Erro ao carregar fornecedor:', err);
        setError('Não foi possível carregar os dados do fornecedor.');
      });
  }, [id]);

  const handleDelete = () => {
    if (window.confirm('Tem certeza que deseja excluir este fornecedor?')) {
      deleteFornecedor(id)
        .then(() => {
          navigate('/fornecedores');
        })
        .catch(err => {
          console.error('Erro ao excluir fornecedor:', err);
          setError('Falha ao excluir o fornecedor.');
        });
    }
  };

  if (error) {
    return (
      <Container className="mt-4">
        <Alert variant="danger">{error}</Alert>
        <Button as={Link} to="/fornecedores" variant="secondary">
          Voltar para Lista
        </Button>
      </Container>
    );
  }

  if (!fornecedor) {
    return (
      <Container className="mt-4">
        <p>Carregando...</p>
      </Container>
    );
  }

  return (
    <Container className="mt-4">
      <h2>Detalhes do Fornecedor</h2>
      
      <Card className="mb-4">
        <Card.Header as="h5">{fornecedor.nome}</Card.Header>
        <Card.Body>
          <Row className="mb-2">
            <Col md={3} className="fw-bold">CNPJ:</Col>
            <Col md={9}>{fornecedor.cnpj}</Col>
          </Row>
          <Row className="mb-2">
            <Col md={3} className="fw-bold">Endereço:</Col>
            <Col md={9}>{fornecedor.endereco}</Col>
          </Row>
          <Row className="mb-2">
            <Col md={3} className="fw-bold">Bairro:</Col>
            <Col md={9}>{fornecedor.bairro}</Col>
          </Row>
          <Row className="mb-2">
            <Col md={3} className="fw-bold">Município:</Col>
            <Col md={9}>{fornecedor.municipio}</Col>
          </Row>
          <Row className="mb-2">
            <Col md={3} className="fw-bold">CEP:</Col>
            <Col md={9}>{fornecedor.cep}</Col>
          </Row>
        </Card.Body>
      </Card>

      <div className="d-flex justify-content-between">
        <Button as={Link} to="/fornecedores" variant="secondary">
          Voltar para Lista
        </Button>
        <div>
          <Button 
            as={Link} 
            to={`/fornecedores/editar/${fornecedor.id}`} 
            variant="warning" 
            className="me-2"
          >
            Editar
          </Button>
          <Button 
            variant="danger" 
            onClick={handleDelete}
          >
            Excluir
          </Button>
        </div>
      </div>
    </Container>
  );
};

export default FornecedorDetail;
