// Formulário para criar ou editar fornecedor
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getFornecedorById, createFornecedor, updateFornecedor } from '../api/fornecedorService';
import { Form, Button, Container, Row, Col, Alert } from 'react-bootstrap';

const FornecedorForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    nome: '',
    cnpj: '',
    endereco: '',
    bairro: '',
    municipio: '',
    cep: ''
  });

  useEffect(() => {
    if (id) {
      getFornecedorById(id)
        .then(response => {
          setFormData(response.data);
        })
        .catch(err => {
          console.error('Erro ao carregar fornecedor:', err);
          setError('Não foi possível carregar os dados do fornecedor.');
        });
    }
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validação básica
    if (!formData.nome || !formData.cnpj || !formData.endereco || 
        !formData.bairro || !formData.municipio || !formData.cep) {
      setError('Todos os campos são obrigatórios.');
      return;
    }

    const savePromise = id
      ? updateFornecedor(id, formData)
      : createFornecedor(formData);

    savePromise
      .then(() => {
        navigate('/fornecedores');
      })
      .catch(err => {
        console.error('Erro ao salvar fornecedor:', err);
        setError('Falha ao salvar o fornecedor. Verifique os dados e tente novamente.');
      });
  };

  return (
    <Container className="mt-4">
      <h2>{id ? 'Editar Fornecedor' : 'Novo Fornecedor'}</h2>
      
      {error && <Alert variant="danger">{error}</Alert>}
      
      <Form onSubmit={handleSubmit}>
        <Row>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Razão Social</Form.Label>
              <Form.Control
                type="text"
                name="nome"
                value={formData.nome}
                onChange={handleChange}
                required
              />
            </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>CNPJ</Form.Label>
              <Form.Control
                type="text"
                name="cnpj"
                value={formData.cnpj}
                onChange={handleChange}
                required
              />
            </Form.Group>
          </Col>
        </Row>

        <Form.Group className="mb-3">
          <Form.Label>Endereço</Form.Label>
          <Form.Control
            type="text"
            name="endereco"
            value={formData.endereco}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Row>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Bairro</Form.Label>
              <Form.Control
                type="text"
                name="bairro"
                value={formData.bairro}
                onChange={handleChange}
                required
              />
            </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Município</Form.Label>
              <Form.Control
                type="text"
                name="municipio"
                value={formData.municipio}
                onChange={handleChange}
                required
              />
            </Form.Group>
          </Col>
        </Row>

        <Form.Group className="mb-3">
          <Form.Label>CEP</Form.Label>
          <Form.Control
            type="text"
            name="cep"
            value={formData.cep}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <div className="d-flex justify-content-between mt-4">
          <Button variant="secondary" onClick={() => navigate('/fornecedores')}>
            Cancelar
          </Button>
          <Button variant="primary" type="submit">
            Salvar
          </Button>
        </div>
      </Form>
    </Container>
  );
};

export default FornecedorForm;
