// Lista todos os fornecedores
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getFornecedores, deleteFornecedor } from '../api/fornecedorService';
import { Table, Button, Container, Row, Col, Alert } from 'react-bootstrap';

const FornecedorList = () => {
  const [fornecedores, setFornecedores] = useState([]);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    loadFornecedores();
  }, []);

  const loadFornecedores = () => {
    getFornecedores()
      .then(response => {
        setFornecedores(response.data);
        setError('');
      })
      .catch(err => {
        console.error('Erro ao carregar fornecedores:', err);
        setError('Falha ao carregar a lista de fornecedores.');
      });
  };

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza que deseja excluir este fornecedor?')) {
      deleteFornecedor(id)
        .then(() => {
          setMessage('Fornecedor excluído com sucesso!');
          loadFornecedores();
          setTimeout(() => setMessage(''), 3000);
        })
        .catch(err => {
          console.error('Erro ao excluir fornecedor:', err);
          setError('Falha ao excluir o fornecedor.');
        });
    }
  };

  return (
    <Container className="mt-4">
      <Row className="mb-3">
        <Col>
          <h2>Lista de Fornecedores</h2>
        </Col>
        <Col className="text-end">
          <Link to="/fornecedores/novo">
            <Button variant="primary">Novo Fornecedor</Button>
          </Link>
        </Col>
      </Row>

      {message && <Alert variant="success">{message}</Alert>}
      {error && <Alert variant="danger">{error}</Alert>}

      <Table striped bordered hover>
        <thead>
          <tr>
            <th>#</th>
            <th>Nome</th>
            <th>CNPJ</th>
            <th>Município</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {fornecedores.length > 0 ? (
            fornecedores.map(fornecedor => (
              <tr key={fornecedor.id}>
                <td>{fornecedor.id}</td>
                <td>{fornecedor.nome}</td>
                <td>{fornecedor.cnpj}</td>
                <td>{fornecedor.municipio}</td>
                <td>
                  <Link to={`/fornecedores/${fornecedor.id}`}>
                    <Button variant="info" size="sm" className="me-2">Detalhes</Button>
                  </Link>
                  <Link to={`/fornecedores/editar/${fornecedor.id}`}>
                    <Button variant="warning" size="sm" className="me-2">Editar</Button>
                  </Link>
                  <Button 
                    variant="danger" 
                    size="sm" 
                    onClick={() => handleDelete(fornecedor.id)}
                  >
                    Excluir
                  </Button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" className="text-center">Nenhum fornecedor encontrado</td>
            </tr>
          )}
        </tbody>
      </Table>
    </Container>
  );
};

export default FornecedorList;
