// Página inicial
import React from 'react';
import { Container, Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <Container className="mt-5">
      <Card className="text-center">
        <Card.Header>
          <h2>Bem-vindo ao Sistema de Gerenciamento de Fornecedores</h2>
        </Card.Header>
        <Card.Body>
          <Card.Text>
            Este sistema permite gerenciar informações de fornecedores, incluindo cadastro, 
            visualização, edição e exclusão.
          </Card.Text>
          <Button as={Link} to="/fornecedores" variant="primary" size="lg">
            Acessar Fornecedores
          </Button>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default Home;
